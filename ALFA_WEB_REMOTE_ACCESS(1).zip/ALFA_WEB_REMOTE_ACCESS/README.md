# ALFA WEB REMOTE ACCESS

Project browser-only untuk sesi bantuan perangkat yang transparan dan berdasarkan persetujuan. Tidak memakai APK.

## Menjalankan lokal
1. Install Node.js 18 atau lebih baru.
2. Jalankan `npm start`.
3. Buka `http://localhost:3000`.

## Deploy
Deploy folder ini ke server yang menjalankan Node.js. Arahkan domain ke server dan pasang HTTPS melalui reverse proxy/hosting. WebSocket upgrade harus diteruskan sebagai WSS.

## Alur
- Owner membuka `/`, membuat kode sesi 6 karakter.
- Peserta membuka `/join`, memasukkan kode, lalu bergabung.
- Peserta dapat memilih sendiri untuk membagikan layar melalui browser.
- Peserta dapat menekan tombol lokasi untuk meminta izin geolocation.

## Batasan penting
- Ini starter project signaling dan consent UI, bukan RAT penuh.
- Screen share hanya tampil pada perangkat peserta; streaming WebRTC peer-to-peer belum diimplementasikan pada starter ini.
- Lokasi pada contoh ini hanya ditampilkan lokal, tidak dikirim ke dashboard.
- Tidak ada tracking saat tab ditutup, layar terkunci, atau browser dihentikan.
- Browser tidak dapat membaca SMS/chat, mengunci Android, mengganti wallpaper, atau mengakses file pribadi tanpa pemilih dan tindakan pengguna.
- Gunakan Find Hub / Find My Device untuk menemukan perangkat Android yang hilang.
- Sebelum penggunaan publik, tambahkan autentikasi kuat, TLS/WSS, rate limiting, expiry sesi, logging, persistence yang aman, dan audit keamanan.
