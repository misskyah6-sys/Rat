const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const PORT = process.env.PORT || 3000;
const sessions = new Map();
const clients = new Map();

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, `http://${req.headers.host}`).pathname;
  const routes = {"/": "index.html", "/join": "join.html"};
  const file = routes[pathname] || (pathname.startsWith("/public/") ? pathname.slice(1) : null);
  if (!file) { res.writeHead(404); return res.end("Not found"); }
  const full = path.join(ROOT, file);
  if (!full.startsWith(ROOT) || !fs.existsSync(full)) { res.writeHead(404); return res.end("Not found"); }
  const ext = path.extname(full);
  const types = {".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css"};
  res.writeHead(200, {"Content-Type": types[ext] || "application/octet-stream", "Cache-Control":"no-store"});
  fs.createReadStream(full).pipe(res);
});

server.on("upgrade", (req, socket) => {
  const key = req.headers["sec-websocket-key"];
  if (!key || req.headers.upgrade?.toLowerCase() !== "websocket") return socket.destroy();
  const accept = crypto.createHash("sha1").update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest("base64");
  socket.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n");
  let buffer = Buffer.alloc(0), sessionCode = null, role = null;
  function send(obj) {
    if (socket.destroyed) return;
    const data = Buffer.from(JSON.stringify(obj));
    let header;
    if (data.length < 126) header = Buffer.from([0x81, data.length]);
    else if (data.length < 65536) { header = Buffer.alloc(4); header[0]=0x81; header[1]=126; header.writeUInt16BE(data.length,2); }
    else return;
    socket.write(Buffer.concat([header,data]));
  }
  socket.on("data", chunk => {
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length >= 2) {
      const masked = !!(buffer[1] & 0x80); let len = buffer[1] & 0x7f, off = 2;
      if (len === 126) { if(buffer.length<4) return; len=buffer.readUInt16BE(2); off=4; }
      if (len === 127) return socket.destroy();
      if (masked) off += 4;
      if (buffer.length < off + len) return;
      let payload = buffer.subarray(off, off+len);
      if (masked) { const mask=buffer.subarray(off-4,off); payload=Buffer.from(payload); for(let i=0;i<payload.length;i++) payload[i]^=mask[i%4]; }
      buffer = buffer.subarray(off+len);
      let msg; try { msg=JSON.parse(payload.toString()); } catch { continue; }
      if (msg.type === "join") {
        sessionCode = String(msg.code || "").toUpperCase();
        role = msg.role === "owner" ? "owner" : "participant";
        if (!/^[A-Z0-9]{6}$/.test(sessionCode)) { send({type:"error",message:"Kode sesi tidak valid"}); continue; }
        if (role === "owner" && !sessions.has(sessionCode)) sessions.set(sessionCode, {owner:null, participant:null});
        const s=sessions.get(sessionCode);
        if (!s) { send({type:"error",message:"Sesi tidak ditemukan"}); continue; }
        s[role]=socket; clients.set(socket,{sessionCode,role});
        send({type:"joined",role,code:sessionCode});
        const other=s[role==="owner"?"participant":"owner"];
        if (other && !other.destroyed) { send({type:"peer-online"}); try { other.write(frame({type:"peer-online"})); } catch {} }
      } else if (sessionCode && ["offer","answer","ice","hangup"].includes(msg.type)) {
        const s=sessions.get(sessionCode); const other=s?.[role==="owner"?"participant":"owner"];
        if (other && !other.destroyed) other.write(frame(msg));
      }
    }
  });
  socket.on("close", () => {
    const c=clients.get(socket); if (!c) return;
    const s=sessions.get(c.sessionCode);
    if (s) { s[c.role]=null; const other=s[c.role==="owner"?"participant":"owner"]; if(other&&!other.destroyed) other.write(frame({type:"peer-offline"})); if(!s.owner&&!s.participant) sessions.delete(c.sessionCode); }
    clients.delete(socket);
  });
  socket.on("error",()=>{});
  function frame(obj) { const b=Buffer.from(JSON.stringify(obj)); if(b.length<126)return Buffer.concat([Buffer.from([0x81,b.length]),b]); const h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(b.length,2);return Buffer.concat([h,b]); }
});
server.listen(PORT, () => console.log(`ALFA WEB listening on ${PORT}`));